"use client";

import { useState } from "react";

const Login = () => {
  const [user, setUser] = useState({ email: "", password: "" });

  const handleChange = (e) => {
    console.log(e);
    setUser({ ...user, [e.target.name]: e.target.value });
  };


  const formSubmit = async (e) => {
    e.preventDefault();
    try {
        const response = await fetch('http://localhost:5000/api/auth/login',{
            method:'Post',
            body:JSON.stringify(user),
            headers: { 'Content-Type': 'application/json' },
        });

        console.log(response)
        if (response.ok) {
            setUser({ email: '', password: ''});
            
            alert('Login successful!');
        }
        else{
            alert('login failed');
            console.log('login failed:',response.statusText)
        }

    } catch (error) {
        console.error('login:', error.message);
    }

    
  };

  return (
    <>
      <section className="pb-4">
        <div className="container">
          <h2 className="fw-bold text-center pt-3">Login</h2>.
          <div className="row">
            <div className="col-md-4"></div>
            <div className="col-md-4">
              <form className="form  border p-3 rounded" onSubmit={formSubmit}>
                <div className="mb-3">
                  <label htmlFor="exampleInputEmail1" className="form-label">
                    Email address
                  </label>
                  <input
                    type="email"
                    name="email"
                    className="form-control"
                    id="exampleInputEmail1"
                    value={user.email}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="mb-3">
                  <label htmlFor="Password" className="form-label">
                    Password
                  </label>
                  <input
                    type="text"
                    name="password"
                    className="form-control"
                    id="Password "
                    value={user.password}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="mb-2">
                  <input
                    type="submit"
                    className="form-control btn btn-primary"
                    value={"Login"}
                  />
                </div>
              </form>
            </div>
            <div className="col-md-3"></div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Login;
