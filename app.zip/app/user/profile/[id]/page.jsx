const page = ({ params }) => {
  console.log(params);
  return <div>Profile {params.id}</div>;
};

export default page;
