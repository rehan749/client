

const pages = () => {
  return (
    <div>Admin profile</div>
  )
}

export default pages