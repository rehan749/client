import AdminLayout from "@/component/AdminLayout";

export default function AdminLayouts ({children}){
return(
    <div>
    <AdminLayout />
   {children}
    </div>
)
}