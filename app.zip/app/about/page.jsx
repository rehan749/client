
export const metadata = {
  title: 'About us',
  description: 'this is about page',
}
const page = () => {
  return (
    <div>About us page</div>
  )
}

export default page