"use client";

import  { useState } from 'react';
import { useRouter } from 'next/navigation'




const Register = () => {
    const [user, setUser] = useState({
      name: '',
      email: '',
      number:'',
      password: '',
    });



// handling the input values 

    const handleChange = (e) => {

      console.log(e);
    // let name= e.target.name;
    // let value= e.target.value;

    // setUser({ ...user,
    //             [name]:value,
    // })

      setUser({ ...user, [e.target.name]: e.target.value });
    };

// handling the form 


// const formSubmit = async (e) => {
//   e.preventDefault();

//   console.log(user)
//   try {
//     const response = await axios.post('http://localhost:3000/register', formData);
//     console.log(response.data);
//   } 
//   catch (error) {
//     console.error(error);
//   }
// };

const router = useRouter()

    const formSubmit = async (e) => {
        e.preventDefault();
        
        try {
          const response = await fetch('http://localhost:5000/api/auth/register', {
            method: 'POST',
            body: JSON.stringify(user),
            headers: { 'Content-Type': 'application/json' },
          });
      
          console.log(response);

          if (response.ok) {
            // Handle successful response (e.g., show a success message)
            setUser({name: '', email: '', number:'', password: ''});
            
            console.log('Registration successful!');
            router.push('/login')
            
          } else {
            // Handle errors if the response is not okay (e.g., show an error message)
            console.error('Registration failed:', response.statusText);
          }
        } 
        catch (error) {
          // Handle any network errors or exceptions from the fetch request
          console.error('Registration:', error.message);
        }
      };
      
    return (
        <section className='pb-4'>
            <div className="container">


                <h2 className='fw-bold text-center pt-3'>Register</h2>.
                <div className="row">
                    <div className="col-md-4"></div>
                    <div className="col-md-4">
                        <form className='form  border p-3 rounded' onSubmit={formSubmit}>
                            <div className="mb-3">
                                <label htmlFor="name" className="form-label">Full Name</label>
                                <input type="text" name='name' className="form-control" id="name" 
                                    value={user.name} onChange={handleChange} required />

                            </div>
                            <div className="mb-3">
                                <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
                                <input type="email" name='email' className="form-control" id="exampleInputEmail1" 
                                   value={user.email} onChange={handleChange} required />

                            </div>
                            <div className="mb-3">
                                <label htmlFor="number" className="form-label">Number</label>
                                <input type="text" name='number' className="form-control" id="number" 
                                    value={user.number} onChange={handleChange} required />

                            </div>
                            <div className="mb-3">
                                <label htmlFor="Password" className="form-label">Password</label>
                                <input type="text" name='password' className="form-control" id="Password " 
                                value={user.password} onChange={handleChange}  required />
                            </div>
                            <div className="mb-2">

                                <input type="submit" className="form-control btn btn-success" value={"Register"} />
                            </div>
                            <div className="mb-2">
                                <p className='text-center'>or</p>
                                <input type="submit" className="form-control btn btn-outline-danger" value={"Login With Google"} />
                            </div>
                        </form>
                    </div>
                    <div className="col-md-3"></div>
                </div>
            </div>
        </section>
    )
}

export default Register