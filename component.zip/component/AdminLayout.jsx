import React from 'react'

const AdminLayout = () => {
  return (
    <div>AdminLayout menu</div>
  )
}

export default AdminLayout