const getData = async () => {
  const res = await fetch("https://jsonplaceholder.typicode.com/posts");
  return res.json();
};

const DataFetching = async () => {
  const data = await getData()

  return (
    <>
      {data.map((post, i) => {
        <div key={i}>
          <h1>{post.title}</h1>
          <p>{post.body}</p>
          <hr />
        </div>;
      })}
    </>
  );
};

export default DataFetching;
