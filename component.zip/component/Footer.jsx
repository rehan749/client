

const Footer = () => {
  return (
    <div className='border-top py-3'>
        <p className='text-center'>Copyright ©2023 All rights reserved  </p>
    </div>
  )
}

export default Footer