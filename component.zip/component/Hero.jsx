

const Hero = () => {
  return (
   <>
   <img src="./banner.jpg" className='img-fluid' alt="" />
   </>
  )
}

export default Hero