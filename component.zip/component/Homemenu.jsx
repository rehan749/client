import React from 'react'
import '../app/style.css'

const Homemenu = () => {
  return (
    <>
    <div className="container py-5">

   
    <div className="row menu-items">
      <div className='text-center pb-3'>
        <h3 className='fw-bold'>Check Out</h3>
        <h3 className='fw-bold text-danger'>Menu</h3>
      </div>
        <div className="col-md-3">
        <div className="card" >
  <img src="./pizza.jpg" className="card-img-top" alt="..." />
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Cheese is one of the best pizza toppings loved by veg and non-veg pizza lovers. </p>
    <a href="#" className="btn btn-danger">Add to cart</a>
  </div>
</div>
        </div>
        <div className="col-md-3">
        <div className="card" >
        <img src="./pizza.jpg" className="card-img-top" alt="..." />
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Cheese is one of the best pizza toppings loved by veg and non-veg pizza lovers. </p>
    <a href="#" className="btn btn-danger">Add to cart</a>
  </div>
</div>
        </div>
        <div className="col-md-3">
        <div className="card" >
        <img src="./pizza.jpg" className="card-img-top" alt="..." />
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Cheese is one of the best pizza toppings loved by veg and non-veg pizza lovers. </p>
    <a href="#" className="btn btn-danger">Add to cart</a>
  </div>
</div>
        </div>
        <div className="col-md-3">
        <div className="card" >
        <img src="./pizza.jpg" className="card-img-top" alt="..." />
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Cheese is one of the best pizza toppings loved by veg and non-veg pizza lovers. </p>
    <a href="#" className="btn btn-danger">Add to cart</a>
  </div>
</div>
        </div>

        <div className="py-3"></div>
        <div className="col-md-3">
        <div className="card" >
        <img src="./pizza.jpg" className="card-img-top" alt="..." />
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Cheese is one of the best pizza toppings loved by veg and non-veg pizza lovers. </p>
    <a href="#" className="btn btn-danger">Add to cart</a>
  </div>
</div>
        </div>
        <div className="col-md-3">
        <div className="card" >
        <img src="./pizza.jpg" className="card-img-top" alt="..." />
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Cheese is one of the best pizza toppings loved by veg and non-veg pizza lovers. </p>
    <a href="#" className="btn btn-danger">Add to cart</a>
  </div>
</div>
        </div>
        <div className="col-md-3">
        <div className="card" >
        <img src="./pizza.jpg" className="card-img-top" alt="..." />
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Cheese is one of the best pizza toppings loved by veg and non-veg pizza lovers. </p>
    <a href="#" className="btn btn-danger">Add to cart</a>
  </div>
</div>
        </div>
        <div className="col-md-3">
        <div className="card" >
        <img src="./pizza.jpg" className="card-img-top" alt="..." />
  <div className="card-body">
    <h5 className="card-title">Card title</h5>
    <p className="card-text">Cheese is one of the best pizza toppings loved by veg and non-veg pizza lovers. </p>
    <a href="#" className="btn btn-danger">Add to cart</a>
  </div>
</div>
        </div>
        </div>
    </div>
    </>
  )
}

export default Homemenu